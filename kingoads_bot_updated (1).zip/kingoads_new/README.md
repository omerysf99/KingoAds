# 👑 KingoAds — Telegram Reklam Botu

TRX ödemeli Telegram reklam yayın sistemi. Kanal sahipleri kazanır, reklamverenler DM ile başvurur.

---

## 🚀 Kurulum

### 1. Repoyu Klonla / Dosyaları Sunucuya At

```bash
git clone <repo_url>
cd kingoads
```

### 2. .env Dosyasını Oluştur

```bash
cp .env.example .env
nano .env
```

**.env içine yazacakların:**

```env
BOT_TOKEN=BotFather'dan_aldığın_token
ADMIN_IDS=telegram_id_numaranız
ADMIN_USERNAME=@dm_kullanıcı_adınız
REQUIRED_CHANNEL=@KanalAdınız
TRX_ADDRESS=TRX_cüzdan_adresiniz
TRX_TO_TRY=8.5
```

> Telegram ID'nizi bilmiyorsanız @userinfobot'a /start yazın.

### 3. Bağımlılıkları Yükle

```bash
pip install -r requirements.txt
```

### 4. Botu Başlat

```bash
python bot.py
```

---

## ☁️ Railway / Render / VPS ile Deploy

### Railway veya Render

1. GitHub'a push edin
2. New Project → repo seçin
3. Environment Variables kısmına .env içindeki değerleri girin
4. **Start Command:** `python bot.py`
5. Deploy

> `Procfile` ve `runtime.txt` zaten hazır, otomatik algılanır.

### VPS (Ubuntu/Debian) — Arka Planda Çalıştırma

```bash
# Systemd servisi oluştur
sudo nano /etc/systemd/system/kingoads.service
```

```ini
[Unit]
Description=KingoAds Telegram Bot
After=network.target

[Service]
WorkingDirectory=/home/ubuntu/kingoads
EnvironmentFile=/home/ubuntu/kingoads/.env
ExecStart=/usr/bin/python3 bot.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl enable kingoads
sudo systemctl start kingoads
sudo systemctl status kingoads   # kontrol
```

---

## 📁 Dosya Yapısı

```
kingoads/
├── bot.py                  # Ana giriş noktası
├── config.py               # Konfigürasyon
├── database.py             # SQLite veritabanı (kingoads.db)
├── requirements.txt        # Python bağımlılıkları
├── Procfile                # Railway/Render için start komutu
├── runtime.txt             # Python versiyonu
├── .env.example            # Örnek environment variables
├── handlers/
│   ├── common.py           # /start, ana menü
│   ├── advertiser.py       # Reklamlarım ekranı
│   ├── channel_owner.py    # Kanal ekle, kazanç, para çek
│   └── admin.py            # Admin paneli
└── services/
    └── scheduler.py        # Otomatik reklam gönderimi
```

---

## 💡 Notlar

- Veriler `kingoads.db` adlı SQLite dosyasında tutulur, ekstra servis gerekmez.
- TRX/TL kurunu `.env` dosyasındaki `TRX_TO_TRY` ile manuel güncelleyin.
- Reklamverenler bota "Reklam Ver" yazınca direkt DM'inize yönlendirilir.
